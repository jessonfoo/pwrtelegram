<?php

namespace Rollbar;

class FakeLog
{
    // log($level, $message)
    public function log()
    {
    }
}
