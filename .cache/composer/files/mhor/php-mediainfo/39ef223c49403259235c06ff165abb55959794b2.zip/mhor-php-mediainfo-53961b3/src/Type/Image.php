<?php

namespace Mhor\MediaInfo\Type;

class Image extends AbstractType
{
}
