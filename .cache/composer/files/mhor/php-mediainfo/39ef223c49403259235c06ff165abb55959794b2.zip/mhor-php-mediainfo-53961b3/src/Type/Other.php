<?php

namespace Mhor\MediaInfo\Type;

class Other extends AbstractType
{
}
