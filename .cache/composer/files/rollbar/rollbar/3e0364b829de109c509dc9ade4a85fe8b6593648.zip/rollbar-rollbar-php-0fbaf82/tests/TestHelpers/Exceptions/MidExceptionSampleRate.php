<?php namespace Rollbar\TestHelpers\Exceptions;

class MidExceptionSampleRate extends \Exception
{
}
