<?php

namespace Mhor\MediaInfo\Test\Stub;

use Mhor\MediaInfo\Type\AbstractType;

class TrackTestType extends AbstractType
{
}
