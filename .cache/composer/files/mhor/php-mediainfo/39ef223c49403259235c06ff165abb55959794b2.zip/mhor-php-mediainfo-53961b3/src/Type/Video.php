<?php

namespace Mhor\MediaInfo\Type;

class Video extends AbstractType
{
}
