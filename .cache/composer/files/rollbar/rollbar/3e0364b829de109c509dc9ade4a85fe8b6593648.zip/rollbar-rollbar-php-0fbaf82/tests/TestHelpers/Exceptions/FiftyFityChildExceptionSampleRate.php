<?php namespace Rollbar\TestHelpers\Exceptions;

class FiftyFityChildExceptionSampleRate extends FiftyFiftyExceptionSampleRate
{
}
