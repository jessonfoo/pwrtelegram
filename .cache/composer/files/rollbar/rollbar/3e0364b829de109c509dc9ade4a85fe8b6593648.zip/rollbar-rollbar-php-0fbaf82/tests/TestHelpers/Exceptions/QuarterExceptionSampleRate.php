<?php namespace Rollbar\TestHelpers\Exceptions;

class QuarterExceptionSampleRate extends FiftyFiftyExceptionSampleRate
{
}
