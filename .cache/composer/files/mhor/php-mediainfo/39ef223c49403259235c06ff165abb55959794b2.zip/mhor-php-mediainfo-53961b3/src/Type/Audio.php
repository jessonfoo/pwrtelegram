<?php

namespace Mhor\MediaInfo\Type;

class Audio extends AbstractType
{
}
