<?php

namespace Mhor\MediaInfo\Type;

class Subtitle extends AbstractType
{
}
