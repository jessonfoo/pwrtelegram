<?php

namespace Mhor\MediaInfo\Type;

class General extends AbstractType
{
}
