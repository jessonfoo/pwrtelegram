<?php namespace Rollbar\TestHelpers\Exceptions;

class SilentExceptionSampleRate extends MidExceptionSampleRate
{
}
