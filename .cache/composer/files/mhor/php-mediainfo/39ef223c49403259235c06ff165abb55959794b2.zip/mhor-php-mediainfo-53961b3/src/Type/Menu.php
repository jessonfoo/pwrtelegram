<?php

namespace Mhor\MediaInfo\Type;

class Menu extends AbstractType
{
}
